Example output files from previous versions of darshan.  In some cases the
target system (surveyor @ ANL) had an incorrect clock at the time that these
samples were collected.
